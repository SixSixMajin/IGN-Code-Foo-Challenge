package Project3;

//import java.util.ArrayList;

public class Space 
{
	public int X,Y;
	public static int moves = 0, mainMoves = 0;
	public int moveNum;
	public boolean traveled;
	public static Space[] availableMoves;
	
	public Space()
	{
		
	}
	
	public Space(int x, int y)
	{
		X = x;
		Y = y;
		moves = 0;
		mainMoves = 0;
		traveled = false;
	}
	
	public void copy(Space s)
	{
		this.X = s.X;
		this.Y = s.Y;
		this.moves = 0;
	}
	
	public void simulateMove(Space[][] c)
	{
		availableMoves = new Space[8];
		
		setMoves(X-1, Y-2, c);
		setMoves(X-1, Y+2, c);
		
		setMoves(X-2, Y-1, c);
		setMoves(X-2, Y+1, c);
		
		setMoves(X+1, Y-2, c);
		setMoves(X+1, Y+2, c);
		
		setMoves(X+2, Y-1, c);
		setMoves(X+2, Y+1, c);

		
		
	}
	
	public void setMoves(int m)
	{
		this.moves = m;
	}
	public void setMoves(int x, int y, Space[][] c)
	{
		if(x>=0 && x<8)
			if(y>=0 && y<8)
				if(!c[x][y].getTraveled())
				{
					availableMoves[moves] = c[x][y];
					//availableMoves[moves].setMoves(0);
					//availableMoves[moves].copy(c[x][y]);
					moves++;
					mainMoves++;
				}
	}
	public int getMoves()
	{
		return moves;
	}
	
	public void setMainMoves(int i)
	{
		mainMoves = i;
	}
	public int getMainMoves()
	{
		return mainMoves;
	}
	
	/*
	public void simulateNextMove1(Space[][] c)
	{
		//System.out.println("moves: " + moves);
		//availableMoves[0].simulateNextMove2(c);
		
		simulateNextMove2(c);
		
	}
	*/
	public void simulateNextMove(Space[][] c)
	{
		setNumMoves(X-1, Y-2, c);
		setNumMoves(X+2, Y-1, c);
		
		setNumMoves(X-2, Y+1, c);
		setNumMoves(X-1, Y+2, c);
		
		setNumMoves(X+1, Y+2, c);
		setNumMoves(X+2, Y+1, c);
		
		setNumMoves(X+2, Y-1, c);
		setNumMoves(X+1, Y-2, c);
		
	}

	
	public void setNumMoves(int x, int y, Space[][] c)
	{
		if(x>=0 && x<8)
			if(y>=0 && y<8)
				if(!c[x][y].getTraveled())
				{
					//System.out.println(c[x][y]);
					//availableMoves[moves] = c[x][y];
					moves++;
				}
	}
	public Space compareMoves()
	{
		Space s = new Space();
		for(int i=0; i<moves-1; i++)
		{
			//System.out.println("comparing " +availableMoves[i].getMoves()+" and "
			//		+ availableMoves[i+1].getMoves());
			if(availableMoves[i].getMoves() <= availableMoves[i+1].getMoves())
				s = availableMoves[i];
			else
				s = availableMoves[i+i];
		}
		return s;

	}
	
	public void setMoveNum(int i)
	{
		moveNum = i;
	}
	public int getMoveNum()
	{
		return moveNum;
	}
	
	public int getX()
	{
		return X;
	}
	
	public int getY()
	{
		return Y;
	}
	
	public void setTraveled()
	{
		traveled = true;
	}
	public boolean getTraveled()
	{
		return traveled;
	}
	
	public Space getAvailableMove(int i)
	{
		return availableMoves[i];
	}
	
	public String toString()
	{
		String s = "( " +X+ ", " +Y+ " )";
		return s;
	}
	
	public static void printMoves()
	{
		System.out.println("available moves");
		for(int i=0; i< moves; i++)
		{
			//System.out.println(i);
			System.out.println(availableMoves[i]);
		}
	}
	
	public String printMoveNum()
	{
		String s;
		if(moveNum<10)
			s = "[ " +moveNum+ "] ";
		else
			s = "[" +moveNum+ "] ";
		
		/*
		if(moveNum<10)
			s = "[ " +moveNum+ " " +traveled+ "] ";
		else
			s = "[" +moveNum+ " " +traveled+ "] ";
		*/
		return s;
	}
}

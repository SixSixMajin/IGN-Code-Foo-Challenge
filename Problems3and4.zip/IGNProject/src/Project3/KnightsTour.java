package Project3;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class KnightsTour 
{
	static int X , Y;
	static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	static Scanner myInput = new Scanner(System.in);
	static int n;
	static int numberOfMoves = 0;
	
	static int[] tempMoves = new int[8];
	static Space currentSpace;
	static Space[] spaceArray = new Space[8];
	static Space[][] chessBoard = new Space[8][8];
	
	
	public static void main(String args[])
	{
		for(int i=0; i<8; i++)
		{
			for(int j=0; j<8; j++)
			{
				chessBoard[i][j] = new Space(i,j);
			}
		}
			
		System.out.println("Enter the ROW and COLUMN values between 0 and 7 of the space you wish to start in." +
				"\n and I will traverse the entire board in as few moves as possible using the KNIGHT chess piece.");
		System.out.println("enter ROW");
		X = myInput.nextInt();
		System.out.println("enter COLUMN");
		Y = myInput.nextInt();
		currentSpace = new Space(X, Y);
		//System.out.println(chessBoard[currentSpace.X][currentSpace.Y]);
		//System.out.println(chessBoard[currentSpace.X][currentSpace.Y].getTraveled());
		
		
		//chessBoard[currentSpace.X][currentSpace.Y].traveled = true;
		System.out.println("You entered ( "+ X +", "+ Y +" )");
		//System.out.println("available spaces are:");

		//currentSpace.setMoveNum(0);
		for(int j=0; j<64; j++)
		{
			chessBoard[currentSpace.X][currentSpace.Y].setTraveled();
			currentSpace.simulateMove(chessBoard);
			//currentSpace.printMoves();
			
			if(currentSpace.getMainMoves()==0)
			{
				
			}
			else
			{
				for(int i=0; i<currentSpace.getMainMoves(); i++)
				{
					//System.out.println(currentSpace);
					//spaceArray[i].copy(currentSpace.availableMoves[i]);
					spaceArray[i] = currentSpace.availableMoves[i];
					spaceArray[i].setMoves(0);
					//System.out.println("simulating moves for " + spaceArray[i]);
					spaceArray[i].simulateNextMove(chessBoard);
					//System.out.println("number of moves for " +spaceArray[i]+ " is " +spaceArray[i].getMoves());
					tempMoves[i] = spaceArray[i].getMainMoves();
					//System.out.println("MOVES: " + currentSpace.getMoves());
				}
				
				compareMoves();
				numberOfMoves++;
				//ystem.out.println("moves made: " + numberOfMoves);
				chessBoard[currentSpace.getX()][currentSpace.getY()].setMoveNum(numberOfMoves);
				
				currentSpace.setMainMoves(0);
				//System.out.println("current space: " + currentSpace);
			}
		}
		
		System.out.println("number of moves made :" + numberOfMoves);
		printBoard();
		
	}
	
	public static void simulateMoves()
	{
		n=0;
		
		currentSpace.setMoves(currentSpace.getX()+1,currentSpace.getY()+2, chessBoard);
		currentSpace.setMoves(currentSpace.getX()-1,currentSpace.getY()+2, chessBoard);
		currentSpace.setMoves(currentSpace.getX()+1,currentSpace.getY()-2, chessBoard);
		currentSpace.setMoves(currentSpace.getX()-1,currentSpace.getY()-2, chessBoard);
		
		currentSpace.setMoves(currentSpace.getX()+2,currentSpace.getY()+1, chessBoard);
		currentSpace.setMoves(currentSpace.getX()-2,currentSpace.getY()+1, chessBoard);
		currentSpace.setMoves(currentSpace.getX()+2,currentSpace.getY()-1, chessBoard);
		currentSpace.setMoves(currentSpace.getX()-2,currentSpace.getY()-1, chessBoard);

	}
	
	public static void compareMoves()
	{
		/**
		 * I could not figure out an algorithm for breaking ties properly
		 */
		Space s = new Space();
		s = spaceArray[0];
		int m = tempMoves[0];
		
		if(currentSpace.getMainMoves()!=1)
		{
			for(int i=1; i<currentSpace.getMainMoves(); i++)
			{
				//System.out.println("comparing " +m+" and " +tempMoves[i+1]);
				if(m < tempMoves[i])
				{
					s = spaceArray[i];
				}
			}
		}
		currentSpace = new Space(s.X, s.Y);
		
		clearTempSpaceArray();
		chessBoard[currentSpace.X][currentSpace.Y].setTraveled();

	}
	
	public static void clearTempSpaceArray()
	{
		for(int i=0; i<8; i++)
		{
			tempMoves[i] = 0;
			spaceArray[i] = null;
		}
		//printSpaceArray();
	}
	
	public static void printSpaceArray()
	{
		System.out.println("spaces in spaceArray");
		for(int i=0; i<8; i++)
		{
			System.out.println(spaceArray[i]);
		}
	}
	
	public static void printBoard()
	{
		for(int i=0; i<8; i++)
		{
			for(int j=0; j<8; j++)
			{
				System.out.print(chessBoard[i][j].printMoveNum());
			}
			System.out.print("\n");
		}
	}
}

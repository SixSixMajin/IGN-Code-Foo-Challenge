package Problem4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class GetJobTextGame 
{	
	static String myInput;
	static int intput;
	static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	static Random rando = new Random();
	
	static int hoursLeft = 158,
			time = 10;
	
	static int repoStat = 0,
			pro1stat = 0,
			pro2stat = 0,
			pro3stat = 0,
			pro4stat = 0;
	
	static int fun = 0,
			hunger = 100,
			energy = 100,
			det = 1;
	
	public static void main(String args[]) throws IOException
	{
		System.out.println("Welcome to the text game, Get Dave a Job at IGN!");
		System.out.println("The goal of the game is to manage your time to complete the the tasks required");
		System.out.println("by IGN's Code Foo Challene within the alloted time of ONE WEEK.  Properly manage");
		System.out.println("your time during the course of this project and keep your stats up so you can");
		System.out.println("properly get the project done in time.  If you're too hungry, bored, or tired, it");
		System.out.println("will be detrimental to your ability to work.  Good luck!\n");
		System.out.println("Just type GO press ENTER to get started");
		myInput = input.readLine();
		
		while(!myInput.equals("GO"))
		{
			if(myInput.equals("go"))
			{
				System.out.println("C'mon man!  Say it with feeling!");
				myInput = input.readLine();
			}
			else if(myInput.equals("Go") || myInput.equals("gO"))
			{
				System.out.println("You got one cap in there.  You're getting there.");
				myInput = input.readLine();
			}
			else
			{
				System.out.println("That's not what I told you to type.");
				myInput = input.readLine();
			}
		}
		PrintMainMenu();
	}
	
	public static void PrintMainMenu() throws IOException
	{
		if(IsGameOver())
			EndGame();
		else
		{
			System.out.println("Current time: " + time + ":00");
			System.out.println("Time left: " + hoursLeft/24 + " days  " + hoursLeft%24 + " hours");
			System.out.println("please select an option by typing the appropriate number");
			System.out.println("1. work on project");
			if(fun>0)
				System.out.println("2. have fun (implying programming isn't fun)");
			else
				System.out.println("2. GO HAVE FUN");
			if(hunger<100)
				System.out.println("3. eat");
			else
				System.out.println("3. GO EAT");
			if(energy>0)
				System.out.println("4. sleep");
			else
				System.out.println("4. GET SOME SLEEP");
			System.out.println("5. check stats");
			System.out.println("6. quit");
			
			myInput = input.readLine();
			//System.out.println(myInput);
			
			while(!myInput.equals("1")
					&& !myInput.equals("2")
					&& !myInput.equals("3")
					&& !myInput.equals("4")
					&& !myInput.equals("5")
					&& !myInput.equals("6"))
			{
				System.out.println("That is not a valid selection.  Please choose again");
				myInput = input.readLine();
				//System.out.println(myInput);
			}
			if(myInput.equals("1"))
				PrintMenu1();
			else if(myInput.equals("2"))
				PrintMenu2();
			else if(myInput.equals("3"))
				Eat();
			else if(myInput.equals("4"))
				Sleep();
			else if(myInput.equals("5"))
				CheckStats();
			else if(myInput.equals("6"))
			{
				System.out.println("Are you sure you want to quit? (y/n)");
				myInput = input.readLine().toUpperCase();
				System.out.println(myInput);
				while(!myInput.equals("Y")
						&& !myInput.equals("N")
						&& !myInput.equals("YES")
						&& !myInput.equals("NO"))
				{
					System.out.println("Not a valid input.  Please try again. (y/n)");
					myInput = input.readLine().toUpperCase();
					//System.out.println(myInput);
				}
				if(myInput.equals("N") || myInput.equals("NO"))
					PrintMainMenu();
				else
					System.out.println("Good bye :D");
			}
		}
	}
	
	
	public static void PrintMenu1() throws IOException
	{
		System.out.println("Enter the option you wish to work on");
		System.out.println("1. set up the repository");
		System.out.println("2. work on problem 1: How Many Pennies?");
		System.out.println("3. work on problem 2: The 16:9 Conundrum");
		System.out.println("4. work on problem 3: The Knight's Code");
		System.out.println("5. work on problem 4: Creative Passion!");
		System.out.println("6. back");
		
		myInput = input.readLine();
		//System.out.println(myInput);
		
		while(!myInput.equals("1")
				&& !myInput.equals("2")
				&& !myInput.equals("3")
				&& !myInput.equals("4")
				&& !myInput.equals("5")
				&& !myInput.equals("6"))
		{
			System.out.println("That is not a valid selection.  Please choose again");
			myInput = input.readLine();
			//System.out.println(myInput);
		}
		if(myInput.equals("1"))
			ChooseProject(myInput);
		else if(myInput.equals("2"))
			ChooseProject(myInput);
		else if(myInput.equals("3"))
			ChooseProject(myInput);
		else if(myInput.equals("4"))
			ChooseProject(myInput);
		else if(myInput.equals("5"))
			ChooseProject(myInput);
		else
			PrintMainMenu();
	}
	
	public static void PrintMenu2() throws IOException
	{
		System.out.println("Enter the option of how you wish to have fun");
		System.out.println("1. play video games");
		System.out.println("2. mess around on the internet");
		System.out.println("3. go hang with friends");
		System.out.println("4. back");
		
		myInput = input.readLine();
		//System.out.println(myInput);
		
		while(!myInput.equals("1")
				&& !myInput.equals("2")
				&& !myInput.equals("3")
				&& !myInput.equals("4"))
		{
			System.out.println("That is not a valid selection.  Please choose again");
			myInput = input.readLine();
			//System.out.println(myInput);
		}
		if(myInput.equals("1"))
			HaveFun(myInput);
		else if(myInput.equals("2"))
			HaveFun(myInput);
		else if(myInput.equals("3"))
			HaveFun(myInput);
		else
			PrintMainMenu();
	}
	
	public static void Eat() throws IOException
	{
		System.out.println("You decided to go grab some food.  Bon appetite!\n");
		PassTime();
		
		hunger = 0;
		PrintMainMenu();
	}
	
	public static void Sleep() throws IOException
	{
		System.out.println("Time to get some shut-eye.  Sleep tight!\n");
		for(int i = 0; i<8; i++)
			PassTime();
		
		energy = 100;
		PrintMainMenu();
	}
	
	public static void CheckStats() throws IOException
	{
		System.out.println("Project stats");
		System.out.println("\trepository: " + repoStat);
		System.out.println("\tproblem 1:  " + pro1stat);
		System.out.println("\tproblem 2:  " + pro2stat);
		System.out.println("\tproblem 3:  " + pro3stat);
		System.out.println("\tproblem 4:  " + pro4stat);
		System.out.println("Personal stats");
		System.out.println("\tentertainment:  " + fun);
		System.out.println("\thunger: \t" + hunger);
		System.out.println("\tenergy: \t" + energy + "\n");
		
		PrintMainMenu();
	}
	
	public static void ChooseProject(String c) throws IOException
	{
		int hours;
		if(c.equals("1"))
		{
			if(repoStat==100)
			{
				System.out.println("This portion is already complete.");
				PrintMenu1();
			}
			else
			{
				hours = ParseHours();
				WorkProject(c, hours);
			}
		}
		else if(c.equals("2"))
		{
			if(pro1stat==100)
			{
				System.out.println("This portion is already complete.");
				PrintMenu1();
			}
			else
			{
				hours = ParseHours();
				WorkProject(c, hours);
			}
		}
		else if(c.equals("3"))
		{
			if(pro2stat==100)
			{
				System.out.println("This portion is already complete.");
				PrintMenu1();
			}
			else
			{
				hours = ParseHours();
				WorkProject(c, hours);
			}
		}
		else if(c.equals("4"))
		{
			if(pro3stat==100)
			{
				System.out.println("This portion is already complete.");
				PrintMenu1();
			}
			else
			{
				hours = ParseHours();
				WorkProject(c, hours);
			}
		}
		else if(c.equals("5"))
		{
			if(pro4stat==100)
			{
				System.out.println("This portion is already complete.");
				PrintMenu1();
			}
			else
			{
				hours = ParseHours();
				WorkProject(c, hours);
			}
		}
		
		
		//PassTime();
		PrintMainMenu();
	}
	
	public static void WorkProject(String c, int h)
	{
		for(int i=0; i<h; i++)
		{
			if(IsGameOver())
			{
				
			}
			else if(c.equals("1"))
			{
				if(repoStat==100)
				{
					
				}
				else
				{
					if(i==1)
						System.out.println("You decided to work on setting up your github repository.");
					det = CalcDet();
					repoStat+=(50/det);
					PassTime();
					if(repoStat>=100)
					{
						repoStat = 100;
						System.out.println("The repository on github has been set up!\n");
					}
				}
			}
			else if(c.equals("2"))
			{
				if(pro1stat==100)
				{
					
				}
				else
				{
					if(i==1)
						System.out.println("You decided to work on calculating how many pennies will fit on the\nGolden Gate Bridge.");
					det = CalcDet();
					pro1stat+=(50/det);
					PassTime();
					if(pro1stat>=100)
					{
						pro1stat = 100;
						System.out.println("Oh wow.  That sure is a lot of pennies...  Problem number 1 has been completed!\n");
					}
				}
			}
			else if(c.equals("3"))
			{
				if(pro2stat==100)
				{
					
				}
				else
				{
					if(i==1)
						System.out.println("You decided to work on finding three 16:9 image sizes");
					det = CalcDet();
					pro2stat+=(50/det);
					PassTime();
					if(pro2stat>=100)
					{
						pro2stat = 100;
						System.out.println("Hrmm...  Aspect ratios seem easy enough.  Problem number 2 3has been completed!\n");
					}
				}
			}
			else if(c.equals("4"))
			{
				if(pro3stat==100)
				{
					
				}
				else
				{
					if(i==1)
						System.out.println("You decided to work on the knight's tour problem.");
					det = CalcDet();
					pro3stat+=(10/det);
					PassTime();
					if(pro3stat>=100)
					{
						pro3stat = 100;
						System.out.println("A chess man you are not but you gave it your best best!  Problem number 3 has been completed!\n");
					}
				}
			}
			else if(c.equals("5"))
			{
				if(pro4stat==100)
				{
					
				}
				else
				{
					if(i==1)
						System.out.println("You decided to creatively prove you're passionate.  Put your soul into it!");
					det = CalcDet();
					pro4stat+=(10/det);
					PassTime();
					if(pro4stat>=100)
					{
						pro4stat = 100;
						System.out.println("OH YEAH!  Flex that creative, passionate muscle of yours!  Wait, that sounded kinda bad...\nProblem number 4 has been completed!\n");
					}
				}
			}
		}
	}
	
	public static void HaveFun(String c) throws IOException
	{
		boolean ateWFriends=false;
		int hours;
		int temp;
		
		if(IsGameOver())
		{
			
		}
		else if(c.equals("3"))
		{
			if(time<10)
			{
				System.out.println("it's too early to go hanging out with friends.  Choose again.");
				PrintMenu2();
			}
			else if(time>22)
			{
				System.out.println("it's too late to go hanging out with friends.  Choose again.");
				PrintMenu2();
			}
			else
			{
				for(int i=0; i<5; i++)
				{
					PassTime();
					if(time==11 || time==12 || time==13 || time==17 || time==18 || time==19)
					{
						ateWFriends=true;
						hunger=0;
					}
				}
				System.out.println("You speant a nice, long, hangout with your buddies.  That sure was fun.");
				fun = 100;
				if(ateWFriends)
					System.out.println("Also, while you were out, you guys decided to grab a bite to eat.");
			}
		}
		else
		{
			if(c.equals("1"))
			{
				hours = ParseHours();
				for(int i=0; i<hours; i++)
				{
					if(i==0)
						System.out.println("You decided to play some video games to relieve some boredom.");
					PassTime();
					fun+=40;
				}
			}
			else if(c.equals("2"))
			{
				hours = ParseHours();
				for(int i=0; i<hours; i++)
				{
					if(i==0)
					{
						System.out.println("You decided to messing around on the internet to relieve some boredom.");
						System.out.println("WMaybe you'll find something cool.  Or maybe you'll find nothing and leave\nbored and unsatisfied...");
					}
					PassTime();
					temp = rando.nextInt(100);
					if(temp<=10)
						fun+=10;
					else if(temp>10 && temp<=50)
						fun+=30;
					else if(temp>50 && temp <=90)
						fun+=50;
					else
						fun+=70;
				}
			}
		}
		
		if(fun>=100)
			fun = 100;
		
		System.out.println("");
		PrintMainMenu();
	}
	
	public static void PassTime()
	{
		fun -=20;
		if(fun < 0)
			fun = 0;


		hunger +=20;
		if(hunger > 100)
			hunger = 100;

		
		energy -= 6;
		if(energy < 0)
			energy = 0;
		
		time++;
		if(time == 24)
			time = 0;
		
		hoursLeft--;
		if(hoursLeft<=0)
			hoursLeft=0;
	}
	
	public static int CalcDet()
	{
		det = 1;
		
		if(fun<=0)
			det++;
		if(hunger>=100)
			det*=2;
		if(energy<=0)
			det*=2;
		
		//System.out.println(det);
		
		return det;
	}
	
	public static int ParseHours() throws IOException
	{
		System.out.println("How many hours? (1-9)");
		myInput = input.readLine();
		//System.out.println(myInput);
		
		while(!myInput.equals("1")
				&& !myInput.equals("2")
				&& !myInput.equals("3")
				&& !myInput.equals("4")
				&& !myInput.equals("5")
				&& !myInput.equals("6")
				&& !myInput.equals("7")
				&& !myInput.equals("8")
				&& !myInput.equals("9"))
		{
			System.out.println("Not a valid entry.  Enter how many hours (1-9)");
			myInput = input.readLine();
			//System.out.println(myInput);
		}
		return Integer.parseInt(myInput);
		
	}
	public static boolean IsGameOver()
	{
		if(hoursLeft==0)
			return true;
		else if(repoStat==100
				&& pro1stat==100
				&& pro2stat==100
				&& pro3stat==100
				&& pro4stat==100)
			return true;
		else
			return false;
		
	}
	
	public static void EndGame()
	{
		if(hoursLeft==0)
		{
			System.out.println("Well, that's it.  Times up.  Let's how much you got done.");
			System.out.println("Project stats");
			System.out.println("\trepository: " + repoStat);
			System.out.println("\tproblem 1:  " + pro1stat);
			System.out.println("\tproblem 2:  " + pro2stat);
			System.out.println("\tproblem 3:  " + pro3stat);
			System.out.println("\tproblem 4:  " + pro4stat);
		}
		
		if(repoStat==100 && pro1stat==100 && pro2stat==100 && pro3stat==100 && pro4stat==100)
		{
			System.out.println("AWESOME!  You finised up everything!");
		}
		else if(repoStat>0 && pro1stat>0 && pro2stat>0 && pro3stat>0 && pro4stat>0)
			System.out.println("Well, they said partial credit counts soooo...");
		
		if(repoStat==0 && pro1stat==0 && pro2stat==0 && pro3stat==0 && pro4stat==0)
			System.out.println("Well that's just disappointing... No way in hell are you getting in.\nDid you even TRY?");
		else
		{
			System.out.println("Time to gather up all you've done, get it up on that repository");
			System.out.println("and shoot that email off to the folks at IGN.  Fingers crossed, right?");
		}
			System.out.println("(by the way, in case you couldn't tell, the game is over)");
	}
}
